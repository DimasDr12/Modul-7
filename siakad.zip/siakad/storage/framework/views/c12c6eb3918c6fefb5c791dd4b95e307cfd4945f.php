
<?php $__env->startSection('isi'); ?>
    <h1 class="sub-judul">Input Data Mahasiswa</h1>
    <form action="/tambah/tambahAction" method="">
        <?php echo e(csrf_field()); ?>

        <div class="countainer-form">
            <div class="form-spes-l">
                <label for="nim">NIM</label><br><input type="text" name="nim"><br>
                <label for="nama">Nama</label><br><input type="text" name="nama"><br>
            </div>
            <div class="form-spes-r">
                <label for="email">Email</label><br>
                <input type="text" name="email"><br>
                <label for="alamat">Alamat</label>
                <br>
                <input type="text" name="alamat">
            </div>
        </div>
        <button class="btn">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 3\PAW\Praktikum\Modul 7\siakad\resources\views/tambah.blade.php ENDPATH**/ ?>