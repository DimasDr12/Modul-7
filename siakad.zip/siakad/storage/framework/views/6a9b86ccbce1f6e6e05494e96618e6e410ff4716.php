<div class="footer">
    <div class="count1">
        <img src="https://kompaspedia.kompas.id/wp-content/uploads/2020/08/logo_Universitas-Trunojoyo-Madura-thumb.png"
            alt="logo" class="logo">
        <br>
        <span>Jurusan Teknik Informatika</span><br>
        <span>Universitas Trunojoyo Madura</span><br>
        <span class="sub">Jl. Raya Telang Kecamatan Kamal, Bangkalan</span><br>
        <span class="sub">Universitas Trunojoyo Madura</span><br>
    </div>
    <div class="count">
        <p>Contact</p>
        <p class="sub">Telp : 031-3011146</p>
        <p class="sub">Fax : 031-3011506</p>
        <p class="sub">Email : if.ft@trunojoyo.ac.id</p>
    </div>
    <div class="count">
        <p>Layanan</p>
        <p class="sub">Pembayaran UKT</p>
        <p class="sub">Pendaftaran KP</p>
        <p class="sub">Pendaftaran Wisuda</p>
        <p class="sub">Administrasi</p>
    </div>
    <div class="count">

        <p>Resource</p>
        <p class="sub">e-Journal</p>
        <p class="sub">Portal Tugas Akhir</p>
        <p class="sub">Website Resmi Kampus</p>
        <p class="sub">Download Administrasi</p>
    </div>
</div>

<?php echo $__env->yieldContent('footer'); ?>
<?php /**PATH D:\Kuliah\Semester 3\PAW\Praktikum\Modul 7\siakad\resources\views/layout/footer.blade.php ENDPATH**/ ?>