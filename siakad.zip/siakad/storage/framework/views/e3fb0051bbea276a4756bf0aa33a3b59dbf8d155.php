    
    <?php $__env->startSection('isi'); ?>
        <h1 class="sub-judul">Data Mahasiswa</h1>
        <div class="tampil-mage">
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="countainer-tampil">

                    <div class="tampil-l m">
                        <span class="nama m"><?php echo e($mhs->nama); ?></span><br>
                        <span class="nim m"><?php echo e($mhs->nim); ?></span><br>
                        <span class="alamat m"><?php echo e($mhs->alamat); ?></span><br>
                    </div>

                    <div class="tampil-r m">
                        <div class="coun-icon">
                            <a href="/edit/<?php echo e($mhs->id); ?>"><i style='font-size:24px' class='fa fa-edit'></i></a>
                            <a href="/delete/<?php echo e($mhs->id); ?>">
                                <i class="fa fa-trash-o"style="font-size:20px;color:red"></i>
                            </a>
                        </div>
                        <span class="email"><?php echo e($mhs->email); ?></span>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 3\PAW\Praktikum\Modul 7\siakad\resources\views/index.blade.php ENDPATH**/ ?>