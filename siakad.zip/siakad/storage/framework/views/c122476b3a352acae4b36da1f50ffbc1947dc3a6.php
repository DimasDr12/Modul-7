
<?php $__env->startSection('isi'); ?>
    <h1 class="sub-judul">About Me</h1>
    <center>
        <img src="image/dimas.jpg" alt="dimasGant">
        <h1 class="sub-judul">Dimas Dliyaur Rahman</h1>
    </center>

    <h1 class="sub-judul">Background</h1>
    <p>Saya berasal dari kota Gresik kecamatan Cerme , Cerme merupakan daerah yang dekat dengan perbatasan Lamongan dan
        Surabaya
        Sehingga jalan disana dijadikan jalan pantura atau jalan provinsi. Saya sekolah daerah sendiri yaitu Cerme. Hobi
        saya bermain Gitar ,Tetapi
        tidak bisa bernyanyi jadi tidak disarankan untuk testimoni suara :V. Awal saya berpikir untuk masuk informatika
        karena melihat dunia ini yang sangat pesat berkembangya pada aspek Industri Teknologi. Walaupun saya tidak berlatar
        belakang SMK , Saya tidak akna mundur karena terlambat belajar.</p>
    <h1 class="sub-judul">Suka Duka Praktikum PAW</h1>
    <p>Beruntung sekali karena lab yang di tempati sangat nyaman , Suasana kelas pun sangat nyaman , Semua berjalan dengan
        baik. Tetapi pada materinya ada beberapa yang belum mengerti mungkin banyak aspek-nya yang membuat saya belum
        mengerti, Saya pun tidak cepat dalam mensimpulkan
        pada satu pandang. Mungkin dari saya sendiri .mungkin duka hanya pada modul 6 dan 7 ini yang sangat sulit , karena
        pada
        awalnya modul awal sangat gampang.Sekian dari saya , Kalo emang ini dibaca semoga kak asprak diberikan kesehatan ,
        dan semoga Lulus tepat waktu :V. </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 3\PAW\Praktikum\Modul 7\siakad\resources\views/about.blade.php ENDPATH**/ ?>