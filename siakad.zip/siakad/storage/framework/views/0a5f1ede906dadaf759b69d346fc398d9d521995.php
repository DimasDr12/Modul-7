<div class="count-nav">
    <div class="count-nav-l">
        <p>Siakad</p>
    </div>
    <div class="count-nav-r">
        <ul>
            <li><a href="/home" class="<?php echo e($tittle === 'home' ? 'active' : ''); ?>">Data mahasiswa</a></li>
            <li><a href="/tambah" class="<?php echo e($tittle === 'tambah' ? 'active' : ''); ?>">Input Data</a></li>
            <li><a href="/about" class="<?php echo e($tittle === 'about' ? 'active' : ''); ?>">About Me</a></li>
        </ul>
    </div>
</div>
<?php echo $__env->yieldContent('nav'); ?>
<?php /**PATH D:\Kuliah\Semester 3\PAW\Praktikum\Modul 7\siakad\resources\views/layout/nav.blade.php ENDPATH**/ ?>