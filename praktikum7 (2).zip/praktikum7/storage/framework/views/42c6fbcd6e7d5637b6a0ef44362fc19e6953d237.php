

<?php $__env->startSection('content'); ?>   

    <div class="card">
        <h1 class="center">Universitas Trunojoyo Madura</h1>
        <img src="aku.jpg" alt="diri" width="700px" >
        <h2>Indah Kharisma</h2>
        <h2>Background</h2>
        <p>Nama saya Risma, saya berasal dari Sidoarjo, Saya merupakan anak tunggal. Saya lahir pada 26 Maret 2003. Sekolah Dasar saya di MI Himmatul Ulya, lalu dilanjutkan ke SMP Negeri 2 Krembung, setelah lulus saya melanjutkan ke SMA Negeri 4 Sidoarjo. Untuk bangku kuliah saya memilih Universitas Trunojoyo Madura dan mengambil jurusan Teknik Informatika</p>
        <h2>Suka Duka Praktikum PAW</h2>
        <p>Pertamanya saya agak kesusahan karena jadwal Praktikum PAW sangat mepet dengan jadwal Praktikum Jarkom, tapi untungnya saya bisa melewatinya sampai hari ini tanpa terlambat. Untuk asistensinya juga lumayan, kakak nya menanyai yang belum paham dimana dan menjelaskannya.Untuk sesi praktikumnya sendiri kadang kakaknya terlalu cepat menjelaskan di depan jadi saya kadang ketinggalan materi nya hehe. </p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Risma\OneDrive\Dokumen\Semester 3\PRAKTIKUM\PAW\praktikum7\resources\views/Tblmahasiswa/about.blade.php ENDPATH**/ ?>