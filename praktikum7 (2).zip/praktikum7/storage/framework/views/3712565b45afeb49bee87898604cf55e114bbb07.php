

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Tambah Data</h1>
        <form action="/Tblmahasiswa/hasil" method="GET">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">NRP</label>
                <input type="text" name="nrp" class="form-control" >
              </div>
              <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control">
              </div>
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="text" name="email" class="form-control">
              </div>
              <div class="mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control">
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Risma\OneDrive\Dokumen\Semester 3\PRAKTIKUM\PAW\praktikum7\resources\views/Tblmahasiswa/tambah.blade.php ENDPATH**/ ?>