@extends('layouts.main')

@section('content')
<h1>Data Mahasiswa</h1>
    <div class="container">
        <table class="table table-primary table-striped-columns">
            <tr>
                <td>ID</td>
                <td>NRP</td>
                <td>NAMA</td>
                <td>EMAIL</td>
                <td>ALAMAT</td>
                <td>Action</td>
            </tr>
            @foreach($Tblmahasiswa as $t)   
            <tr>
                <td>{{$t->id}}</td>
                <td>{{$t->nrp}}</td>
                <td>{{$t->nama}}</td>
                <td>{{$t->email}}</td>
                <td>{{$t->alamat}}</td>
                <td>
                    <a ref="/Tblmahasiswa/{{$t->id}}/edit" class="btn btn-info">Edit</a>
                    <form action="/Tblmahasiswa/{{$t->id}}" method="POST">
                        @csrf
                        @method('delete')
                        <input type="submit" value="Delete" class="btn btn-secondary">
                    </form>
                </td>

            </tr>
            @endforeach
        </table>
    </div>
@endsection