<?php

namespace App\Http\Controllers;

use App\Models\Tblmahasiswa;
use Illuminate\Http\Request;

class TblmahasiswaController extends Controller
{
    public function index(){
        $Tblmahasiswa = Tblmahasiswa::all();
        return view('Tblmahasiswa.index',['title'=>'index'],compact(['Tblmahasiswa']));
    }
    public function tambah(){
        return view('Tblmahasiswa.tambah',["title" => "tambah"]);
    }
    public function hasil(Request $request){
        Tblmahasiswa::create($request->except(['_token','submit']));
        return redirect('/Tblmahasiswa');
    }
    public function edit($id){
        $Tblmahasiswa = Tblmahasiswa::find($id);
        return view('Tblmahasiswa.edit',["title" => "edit"],compact(['Tblmahasiswa']));
    }
    public function update($id, Request $request){
        $Tblmahasiswa = Tblmahasiswa::find($id);
        $Tblmahasiswa->update($request->except(['_token','submit']));
        return redirect('/Tblmahasiswa');
    }
    public function delete($id){
        $Tblmahasiswa = Tblmahasiswa::find($id);
        $Tblmahasiswa->delete();
        return redirect('/Tblmahasiswa');
    }
    public function about(){
        return view('Tblmahasiswa.about',["title" => "about"]);
    }
}
